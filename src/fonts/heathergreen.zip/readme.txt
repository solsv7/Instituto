OTF and TTF: Heathergreen (Regular and Italic)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

This relative of Deutschlander is about 20% taller and designed to take up more vertical space. Unlike most of our display fonts this one is designed to fill body text or accompany titles. Included are basic/extended latin Greek, Cyrillic, and many other European accents and diacritics. 
OTF features include ordinals, small caps, stylistic sets, ligatures, and alternates. Squeeze lots of text into your next project such as faux movie posters, labeling, or subtitles. A demo of the regular version is included for personal use. Full version plus Italic can be purchased for $15 or by purchasing 
a commercial license. Please note the $15 purchase is for personal use only. Licensing info can be found by visiting this page: www.sharkshock.net/license

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: modern, stylish, vertical, display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, branding, fancy, sans, serif, italic, strong, narrow, tall, high, poster, headline, neo-grotesque, sports, condensed, ultra, newspaper, news





